//
//  util.cpp
//  syntax
//
//  Created by Ge, Xiao on 11/05/2017.
//  Copyright © 2017 Ge, Xiao. All rights reserved.
//

#include "util.hpp"

int addOne(int a){
    return a+1;
}
