//
//  util.hpp
//  syntax
//
//  Created by Ge, Xiao on 11/05/2017.
//  Copyright © 2017 Ge, Xiao. All rights reserved.
//

#ifndef util_hpp
#define util_hpp

#include <stdio.h>

int addOne(int a);

#endif /* util_hpp */
