//
//  main.cpp
//  equation
//
//  Created by Ge, Xiao on 17/04/2017.
//  Copyright © 2017 Ge, Xiao. All rights reserved.
//

#include <iostream>

using namespace std;

void calcEquation2(){
    cout<<"173+286=459"<<endl;
    cout<<"173+295=468"<<endl;
    cout<<"175+293=468"<<endl;
    cout<<"176+283=459"<<endl;
    cout<<"183+276=459"<<endl;
    cout<<"186+273=459"<<endl;
    cout<<"193+275=468"<<endl;
    cout<<"195+273=468"<<endl;
    cout<<"127+359=486"<<endl;
    cout<<"127+368=495"<<endl;
    cout<<"128+367=495"<<endl;
    cout<<"129+357=486"<<endl;
    cout<<"157+329=486"<<endl;
    cout<<"159+327=486"<<endl;
    cout<<"162+387=549"<<endl;
    cout<<"167+328=495"<<endl;
    cout<<"167+382=549"<<endl;
    cout<<"168+327=495"<<endl;
    cout<<"182+367=549"<<endl;
    cout<<"182+394=576"<<endl;
    cout<<"184+392=576"<<endl;
    cout<<"187+362=549"<<endl;
    cout<<"192+384=576"<<endl;
    cout<<"194+382=576"<<endl;
    cout<<"128+439=567"<<endl;
    cout<<"129+438=567"<<endl;
    cout<<"138+429=567"<<endl;
    cout<<"139+428=567"<<endl;
    cout<<"152+487=639"<<endl;
    cout<<"157+482=639"<<endl;
    cout<<"182+457=639"<<endl;
    cout<<"182+493=675"<<endl;
    cout<<"183+492=675"<<endl;
    cout<<"187+452=639"<<endl;
    cout<<"192+483=675"<<endl;
    cout<<"193+482=675"<<endl;
    cout<<"142+596=738"<<endl;
    cout<<"143+586=729"<<endl;
    cout<<"146+583=729"<<endl;
    cout<<"146+592=738"<<endl;
    cout<<"183+546=729"<<endl;
    cout<<"186+543=729"<<endl;
    cout<<"192+546=738"<<endl;
    cout<<"196+542=738"<<endl;
    cout<<"124+659=783"<<endl;
    cout<<"129+654=783"<<endl;
    cout<<"134+658=792"<<endl;
    cout<<"138+654=792"<<endl;
    cout<<"142+695=837"<<endl;
    cout<<"145+692=837"<<endl;
    cout<<"154+629=783"<<endl;
    cout<<"154+638=792"<<endl;
    cout<<"158+634=792"<<endl;
    cout<<"159+624=783"<<endl;
    cout<<"192+645=837"<<endl;
    cout<<"195+642=837"<<endl;
    cout<<"125+739=864"<<endl;
    cout<<"129+735=864"<<endl;
    cout<<"135+729=864"<<endl;
    cout<<"139+725=864"<<endl;
    cout<<"152+784=936"<<endl;
    cout<<"154+782=936"<<endl;
    cout<<"162+783=945"<<endl;
    cout<<"163+782=945"<<endl;
    cout<<"182+754=936"<<endl;
    cout<<"182+763=945"<<endl;
    cout<<"183+762=945"<<endl;
    cout<<"184+752=936"<<endl;
    cout<<"216+378=594"<<endl;
    cout<<"218+349=567"<<endl;
    cout<<"218+376=594"<<endl;
    cout<<"219+348=567"<<endl;
    cout<<"248+319=567"<<endl;
    cout<<"249+318=567"<<endl;
    cout<<"251+397=648"<<endl;
    cout<<"257+391=648"<<endl;
    cout<<"276+318=594"<<endl;
    cout<<"278+316=594"<<endl;
    cout<<"281+394=675"<<endl;
    cout<<"284+391=675"<<endl;
    cout<<"291+357=648"<<endl;
    cout<<"291+384=675"<<endl;
    cout<<"294+381=675"<<endl;
    cout<<"297+351=648"<<endl;
    cout<<"215+478=693"<<endl;
    cout<<"218+439=657"<<endl;
    cout<<"218+475=693"<<endl;
    cout<<"219+438=657"<<endl;
    cout<<"238+419=657"<<endl;
    cout<<"239+418=657"<<endl;
    cout<<"275+418=693"<<endl;
    cout<<"278+415=693"<<endl;
    cout<<"214+569=783"<<endl;
    cout<<"219+564=783"<<endl;
    cout<<"241+596=837"<<endl;
    cout<<"243+576=819"<<endl;
    cout<<"246+573=819"<<endl;
    cout<<"246+591=837"<<endl;
    cout<<"264+519=783"<<endl;
    cout<<"269+514=783"<<endl;
    cout<<"271+593=864"<<endl;
    cout<<"273+546=819"<<endl;
    cout<<"273+591=864"<<endl;
    cout<<"276+543=819"<<endl;
    cout<<"291+546=837"<<endl;
    cout<<"291+573=864"<<endl;
    cout<<"293+571=864"<<endl;
    cout<<"296+541=837"<<endl;
    cout<<"214+659=873"<<endl;
    cout<<"219+654=873"<<endl;
    cout<<"234+657=891"<<endl;
    cout<<"237+654=891"<<endl;
    cout<<"243+675=918"<<endl;
    cout<<"245+673=918"<<endl;
    cout<<"254+619=873"<<endl;
    cout<<"254+637=891"<<endl;
    cout<<"257+634=891"<<endl;
    cout<<"259+614=873"<<endl;
    cout<<"271+683=954"<<endl;
    cout<<"273+645=918"<<endl;
    cout<<"273+681=954"<<endl;
    cout<<"275+643=918"<<endl;
    cout<<"281+673=954"<<endl;
    cout<<"283+671=954"<<endl;
    cout<<"215+748=963"<<endl;
    cout<<"216+738=954"<<endl;
    cout<<"218+736=954"<<endl;
    cout<<"218+745=963"<<endl;
    cout<<"235+746=981"<<endl;
    cout<<"236+718=954"<<endl;
    cout<<"236+745=981"<<endl;
    cout<<"238+716=954"<<endl;
    cout<<"245+718=963"<<endl;
    cout<<"245+736=981"<<endl;
    cout<<"246+735=981"<<endl;
    cout<<"248+715=963"<<endl;
    cout<<"352+467=819"<<endl;
    cout<<"357+462=819"<<endl;
    cout<<"362+457=819"<<endl;
    cout<<"367+452=819"<<endl;
    cout<<"317+529=846"<<endl;
    cout<<"319+527=846"<<endl;
    cout<<"324+567=891"<<endl;
    cout<<"327+519=846"<<endl;
    cout<<"327+564=891"<<endl;
    cout<<"329+517=846"<<endl;
    cout<<"341+586=927"<<endl;
    cout<<"342+576=918"<<endl;
    cout<<"346+572=918"<<endl;
    cout<<"346+581=927"<<endl;
    cout<<"364+527=891"<<endl;
    cout<<"367+524=891"<<endl;
    cout<<"372+546=918"<<endl;
    cout<<"376+542=918"<<endl;
    cout<<"381+546=927"<<endl;
    cout<<"386+541=927"<<endl;
    cout<<"314+658=972"<<endl;
    cout<<"317+628=945"<<endl;
    cout<<"318+627=945"<<endl;
    cout<<"318+654=972"<<endl;
    cout<<"324+657=981"<<endl;
    cout<<"327+618=945"<<endl;
    cout<<"327+654=981"<<endl;
    cout<<"328+617=945"<<endl;
    cout<<"354+618=972"<<endl;
    cout<<"354+627=981"<<endl;
    cout<<"357+624=981"<<endl;
    cout<<"358+614=972"<<endl;
}

// 校验1-9都用到
int check(int a[]){
    int has[10]={}; // has[x]表示数字x已使用
    has[0]=1;
    for (int i=1;i<=9;i++) {
        if (has[a[i]]){ // 有一个重复，返回失败
            return 0;
        }
        has[a[i]]=1;
    }
    return 1;

    // 以下是一种好的方法，使用了位运算技巧（第7周会讲），不要求
//    int check=0;
//    for (int i=1;i<=9;i++) {
//        check |= (1<<(a[i]-1)); // 利用位运算技巧，每个数对应一个2的幂次
//    }
//    return check==0x1ff;
}

void calcEquation(){
    // a1a2a3 + a4a5a6 = a7a8a9
    int a[10];
    for (a[1]=1;a[1]<=4;a[1]++) { // a1<a4
        for (a[4]=a[1]+1;a[4]<=9-a[1];a[4]++) {
            for (a[2]=1;a[2]<=9;a[2]++) {
                for (a[3]=1;a[3]<=9;a[3]++) {
                    for (a[5]=1;a[5]<=9;a[5]++) {
                        for (a[6]=1;a[6]<=9;a[6]++) {
                            // 计算和
int sum=a[1]*100+a[2]*10+a[3]+a[4]*100+a[5]*10+a[6];
                            a[7]=sum/100;
                            a[8]=sum/10%10;
                            a[9]=sum%10;
                            
                            // 把独立功能的代码单独封装成函数是一个好习惯，代码清晰且方便调试
                            if (check(a)) { // 输出，%d表示一个整数 占位符
                                printf("%d%d%d+%d%d%d=%d%d%d\n",a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8],a[9]);
                            }
                        }
                    }
                }
            }
        }
    }
}

int cpr(int a,int b){
    int s[2],h[2],tt=0;
    for (int i=0;i<=2;i++){
        s[i]=a%10;
        a=a/10;
        h[i]=b%10;
        b=b/10;
    }
    for(int i=0;i<=2;i++){
        for(int j=0;j<=2;j++){
            if((s[i]==s[j])&&(i!=j)) tt=1;
            if (s[i]==h[j]) tt=1;
            if((h[i]==h[j])&&(i!=j)) tt=1;
        }
    }
    return tt;
}

void calcEquationForDebug(){
    int q;
    for(int i=100;i<=500;i++){
        for(int j=500;j<=1000-i;j++){
            q=i+j;
            if ((cpr(i,j)==0)&&(cpr(q,j)==0)&&(cpr(i,q)==0))
                cout<<i<<"+"<<j<<"="<<q<<endl;
        }
    }
}

int main() {
    
//    calcEquation();
//    calcEquation2();
    calcEquationForDebug();
    return 0;
}
