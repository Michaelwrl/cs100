def f (x,b,c,d):
      return x**3+b*(x**2)+c*x+d
b=float(input("b<100 b:"))
c=float(input("c<100 c:"))
d=float(input("d<100 d:"))
p=1
i=-1
while f(i,b,c,d)*f(p,b,c,d)>0:
      p=p+0.5
      i=i-0.5
while i<=p:
      mid=(p+i)/2
      if abs(f(mid,b,c,d))<0.001:
            print(round(mid,3))
            break
      else:
            if f(i,b,c,d)*f(mid,b,c,d)<0:
                  p=mid
            else:
                  i=mid
            
